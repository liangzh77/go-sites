"""Build a standalone, offline scroll-driven HTML from the same scene.json used for MP4."""
import argparse, base64, json
from pathlib import Path
from PIL import Image
from render import load_layer


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('scene',type=Path);p.add_argument('output',type=Path);a=p.parse_args()
    cfg=json.loads(a.scene.read_text());root=a.scene.parent
    if min(cfg['size'])<=0 or cfg['duration']<=0:raise ValueError('Invalid canvas size or duration')
    embedded={}
    for layer in cfg['layers']:
        load_layer(layer,root);name=layer['file'];f=root/name
        if name not in embedded:
            with Image.open(f) as im: mime=Image.MIME.get(im.format)
            if mime not in ('image/png','image/jpeg','image/webp'):raise ValueError('Use PNG, JPEG or WebP')
            embedded[name]='data:'+mime+';base64,'+base64.b64encode(f.read_bytes()).decode('ascii')
        layer['file']=list(embedded).index(name)
    cfg['images']=list(embedded.values());payload=json.dumps(cfg,ensure_ascii=False,separators=(',',':')).replace('<','\\u003c');markup=(Path(__file__).with_name('stage.html')).read_text().replace('__SCENE_JSON__',payload)
    a.output.parent.mkdir(parents=True,exist_ok=True)
    with a.output.open('x',encoding='utf-8') as out:out.write(markup)
    print(a.output.resolve())

if __name__=='__main__':main()
