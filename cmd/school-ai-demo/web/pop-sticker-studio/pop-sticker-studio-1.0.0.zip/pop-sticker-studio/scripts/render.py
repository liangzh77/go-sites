"""Render a layered still-image timeline to a silent H.264 MP4. Requires Pillow + ffmpeg."""
import argparse
import bisect
import json
import math
import os
from pathlib import Path
import subprocess
import tempfile
from PIL import Image, ImageColor

def load_layer(spec, root):
    path = root / spec["file"]
    with Image.open(path) as src:
        img = src.convert("RGBA")
    keys = spec["keys"]
    if not keys or any(len(k) != 6 or not all(math.isfinite(v) for v in k)
                       or k[3] <= 0 or not 0 <= k[5] <= 1 for k in keys):
        raise ValueError(f"Invalid keyframes for {path}")
    times = [k[0] for k in keys]
    if any(a >= b for a,b in zip(times,times[1:])):
        raise ValueError(f"Keyframe times must increase: {path}")
    u,v = spec.get("anchor",[.5,.5])
    return img, keys, times, (img.width*u,img.height*v)

def sample(keys, times, t):
    i = bisect.bisect_right(times,t)-1
    if i < 0: return keys[0][1:]
    if i+1 == len(times): return keys[-1][1:]
    f = (t-times[i])/(times[i+1]-times[i])
    f = f*f*(3-2*f)
    return [a+(b-a)*f for a,b in zip(keys[i][1:],keys[i+1][1:])]

def draw(canvas, layer, t):
    img,keys,times,(ax,ay) = layer
    x,y,w,angle,opacity = sample(keys,times,t)
    if opacity <= .001: return
    W,H = canvas.size
    x,y,scale = x*W,y*H,w*W/img.width
    c,s = math.cos(math.radians(angle)),math.sin(math.radians(angle))
    corners = [(x+scale*(c*(px-ax)-s*(py-ay)), y+scale*(s*(px-ax)+c*(py-ay)))
               for px in (0,img.width) for py in (0,img.height)]
    left=max(0,math.floor(min(i for i,j in corners))-1); right=min(W,math.ceil(max(i for i,j in corners))+1)
    top=max(0,math.floor(min(j for i,j in corners))-1); bottom=min(H,math.ceil(max(j for i,j in corners))+1)
    if right<=left or bottom<=top:return
    # Inverse affine map from this screen crop to the source, rotating about its own anchor.
    a,b=c/scale,s/scale
    coeffs=(a,b,ax+a*(left-x)+b*(top-y),-b,a,ay-b*(left-x)+a*(top-y))
    pic=img.transform((right-left,bottom-top),Image.Transform.AFFINE,coeffs,Image.Resampling.BICUBIC)
    if opacity < 1: pic.putalpha(pic.getchannel("A").point(lambda v:round(v*opacity)))
    canvas.alpha_composite(pic,(left,top))

def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument("scene",type=Path);ap.add_argument("output",type=Path);args=ap.parse_args()
    cfg=json.loads(args.scene.read_text());W,H=cfg["size"];fps=cfg.get("fps",24);duration=cfg["duration"]
    if not all(isinstance(v,int) and v>0 and v%2==0 for v in (W,H)) or not isinstance(fps,int) or fps<1 or duration<=0: raise ValueError("Invalid size, fps or duration")
    layers=[load_layer(l,args.scene.parent) for l in cfg["layers"]]
    color=ImageColor.getrgb(cfg.get("background","#f6eed9"))
    if args.output.exists():raise FileExistsError(f"Choose a new output path: {args.output}")
    args.output.parent.mkdir(parents=True,exist_ok=True)
    with tempfile.TemporaryDirectory(dir=args.output.parent) as tmp:
        dest=Path(tmp)/"film.mp4"
        cmd=["ffmpeg","-v","error","-f","rawvideo","-pix_fmt","rgb24","-s",f"{W}x{H}","-r",str(fps),"-i","pipe:0","-an","-c:v","libx264","-pix_fmt","yuv420p","-movflags","+faststart",str(dest)]
        proc=subprocess.Popen(cmd,stdin=subprocess.PIPE)
        try:
            for n in range(max(1,round(duration*fps))):
                im=Image.new("RGBA",(W,H),color)
                for layer in layers: draw(im,layer,n/fps)
                proc.stdin.write(im.convert("RGB").tobytes())
            proc.stdin.close()
            if proc.wait():raise RuntimeError("FFmpeg did not complete")
            os.link(dest,args.output)
        finally:
            if proc.poll() is None:proc.kill();proc.wait()
    print(args.output.resolve())

if __name__=="__main__":main()
