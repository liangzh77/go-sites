"""Add a warm white die-cut border to a transparent PNG/WebP. No drop shadow."""
import argparse
from pathlib import Path
from PIL import Image,ImageFilter
ap=argparse.ArgumentParser(description=__doc__);ap.add_argument("source",type=Path);ap.add_argument("output",type=Path);ap.add_argument("--px",type=int,default=8)
a=ap.parse_args()
if a.output.exists():ap.error("Choose a new output file")
if not 1<=a.px<=32:ap.error("--px must be 1..32")
with Image.open(a.source) as src:im=src.convert("RGBA")
lo,hi=im.getchannel("A").getextrema()
if lo!=0 or hi==0:ap.error("Input must have a visible subject and genuinely transparent background")
# Equal padding for every pose keeps identically framed variants registered.
r=a.px;pad=Image.new("RGBA",(im.width+2*r,im.height+2*r));pad.alpha_composite(im,(r,r))
alpha=pad.getchannel("A").point(lambda x:255 if x>=64 else 0).filter(ImageFilter.MaxFilter(2*r+1)).filter(ImageFilter.GaussianBlur(.6))
out=Image.new("RGBA",pad.size,"#fff6dd");out.putalpha(alpha);out.alpha_composite(pad);a.output.parent.mkdir(parents=True,exist_ok=True);out.save(a.output)
